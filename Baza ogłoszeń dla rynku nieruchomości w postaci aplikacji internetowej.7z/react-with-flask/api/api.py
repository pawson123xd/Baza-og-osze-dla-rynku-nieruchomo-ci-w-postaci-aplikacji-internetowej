import time ,os
from flask import Flask
from flask import Flask,redirect, request, session ,render_template,url_for ,jsonify,render_template_string
from flask_mysqldb import MySQL
from argon2 import PasswordHasher
from flask_cors import CORS
app = Flask(__name__)
CORS(app, origins=["http://localhost:5173"])
message=False
app.secret_key = '123456345645'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'offer'
mysql = MySQL(app)
def is_create_page(Sell_or_Rent, Meters, Price, Description, Address, City, Image,Data,update):
    if update==False:
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT idogłoszenia FROM ogłoszenia ORDER BY Data DESC LIMIT 1')
        result = cursor.fetchone()[0]
        count = result
        images = "" 
        for index, img in enumerate(Image):
            if index == len(Image) - 1 or index == 0:
                images += img + "\n"
            else:
                images += img + "=\n"
        file=open(f'../offer/{str(count)}.txt',"w", encoding="utf-8")
        file.write(str(images))
        images=""
        for img in Image:
            images+=f'''
            <div class="container">
                <div class="row">
                    <img class="col-12 mt-3" src="{str(img)}">
                </div>
        </div>
        '''
        html=f'''<!doctype html>
    <html lang="pl">
    <head>
        <meta charset="UTF-8" />
        <link rel="icon" type="image/svg+xml" href="/vite.svg" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Vite + React</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>
    <body  class="d-flex flex-column min-vh-100">
        <div id="offer">
        </div>
        <div class="filters border border-dark">
            <div class="windows mt-5">
            <div class="container">
                <div class="row">
                <div class="col-lg-2 col-12"></div>
                <div class="col-lg-2 col-12">
                    Miasto:{City}
                </div>
                <div class="col-lg-2 col-12">
                    Adres:{Address}
                </div>
                <div class="col-lg-2 col-12">
                    Data:{Data}
                </div>
                <div class="col-lg-2 col-12">
                    Kontakt:{session['email']}
                </div>
            </div>
            </div>
            <div class="windows mt-5">
            <div class="container">
                <div class="row">
                <div class="col-lg-2 col-12"></div>
                <div class="col-lg-2 col-12">
                    Cena:{Price} zł
                </div>
                <div class="col-lg-2 col-12">
                    Metry:{Meters} M^2
                </div>
                <div class="col-lg-2 col-12">
                    Rodzja:{Sell_or_Rent}
                </div>
                </div>
            </div>
            </div>
        </div>
            <div class="windows mt-5">
            <div class="container">
                <div class="row">
                <div class="col-1">
                    Opis:
                </div>
                </div>
            </div>
            <div class="windows">
            <div class="container">
                <div class="row">
                <div class="col-1"></div>
                <div class="col-2 p-3">
                    {Description}
                </div>
                </div>
            </div>
            </div>
            </div>
        </div>
        {images}
        </div>
        <script type="module" src="../src/main.jsx"></script>
    </body>
    </html>
    '''
        file=open(f'../offer/{str(count)}.html',"w")
        file.write(str(html))
    else:
        images=""
        for index, img in enumerate(Image):
            if index == len(Image) - 1 or index == 0:
                images += img + "\n"
            else:
                images += img + "=\n"
        file=open(f'../offer/{str(session['id_offer'])}.txt',"w", encoding="utf-8")
        file.write(str(images))
        images=""
        for img in Image:
            images+=f'''
            <div class="container">
                <div class="row">
                    <img class="col-12 mt-3" src="{str(img)}">
                </div>
        </div>
        '''
        html=f'''<!doctype html>
    <html lang="pl">
    <head>
        <meta charset="UTF-8" />
        <link rel="icon" type="image/svg+xml" href="/vite.svg" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Vite + React</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>
    <body  class="d-flex flex-column min-vh-100">
        <div id="offer">
        </div>
        <div class="filters border border-dark">
            <div class="windows mt-5">
            <div class="container">
                <div class="row">
                <div class="col-lg-2 col-12">
                    Miasto:{City}
                </div>
                <div class="col-lg-2 col-12">
                    Adres:{Address}
                </div>
                <div class="col-lg-2 col-12">
                    Data:{Data}
                </div>
                <div class="col-lg-2 col-12">
                    Kontakt:{session['email']}
                </div>
            </div>
            </div>
            <div class="windows mt-5">
            <div class="container">
                <div class="row">
                <div class="col-lg-2 col-12">
                    Cena:{Price} zł
                </div>
                <div class="col-lg-2 col-12">
                    Metry:{Meters} M^2
                </div>
                <div class="col-lg-2 col-12">
                    Rodzja:{Sell_or_Rent}
                </div>
                </div>
            </div>
            </div>
        </div>
            <div class="windows mt-5">
            <div class="container">
                <div class="row">
                <div class="col-1">
                    Opis:
                </div>
                </div>
            </div>
            <div class="windows">
            <div class="container">
                <div class="row">
                <div class="col-1"></div>
                <div class="col-2 p-3">
                    {Description}
                </div>
                </div>
            </div>
            </div>
            </div>
        </div>
        {images}
        </div>
        <script type="module" src="../src/main.jsx"></script>
    </body>
    </html>
    '''
        file=open(f'../offer/{str(session['id_offer'])}.html',"w", encoding="utf-8")
        file.write(str(html))

@app.route('/api/time')
def get_current_time():
    return {'time': time.time()}

@app.route('/api/register',methods = ['POST', 'GET'])
def get_register():
    global message 
    if request.method=='GET':
        return "ERROR"
    if request.method=='POST':
        cursor = mysql.connection.cursor()  
        email=request.form['email']
        cursor.execute('SELECT COUNT(*) FROM klient WHERE Email=%s', (email,))
        count = cursor.fetchone()[0]
        if count > 0:
            message=True
            return redirect(url_for('rejestracja'))
        name=request.form['name']
        surname=request.form['surname']
        password=PasswordHasher().hash(request.form['password'])
        cursor.execute('''INSERT INTO klient (Imie, Nazwisko, Email , Hasło) VALUES (%s, %s,%s,%s)''', (name,surname,email,password))
        mysql.connection.commit()
        cursor.close()
        message=False
        return redirect(url_for('index'))

@app.route('/api/setuser')
def get_Data():
    user=[{"name":session['name'],"surname":session['surname'],"email":session['email']}];
    return jsonify(user)

@app.route('/api/get_update_user',methods = ['POST', 'GET'])
def get_Update_User():
    global message 
    if request.method == 'GET':
        return "ERROR"
    if request.method == 'POST':
        name = request.form['name']
        surname = request.form['surname']
        password = request.form['password']
        repeat_password = request.form['repeat_password']
        if password!=repeat_password:
            message=True
            return redirect(url_for('setuser'))
        password=PasswordHasher().hash(request.form['password'])
        message=False
        cur = mysql.connection.cursor()
        cur.execute('''UPDATE klient SET Imie = %s , Nazwisko = %s , Hasło = %s  WHERE Email = %s''', (name, surname,password,session['email']))
        mysql.connection.commit()
        cur.close()
        session['name'] = name
        session['surname'] = surname
        message=False
        return redirect(url_for('index'))

@app.route('/api/login',methods = ['POST', 'GET'])
def LogIn():
    global message 
    if request.method == 'GET':
        return "ERROR"
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM klient WHERE Email=%s', (email,))
        rows = cursor.fetchall()
        cursor.close()
        for row in rows:
            try:
                PasswordHasher().verify(row[4], password)
                session['id']=row[0]
                session['name'] = row[1]
                session['surname'] = row[2]
                session['email'] = row[3]
                message=False
                return redirect(url_for('index'))
            except Exception:
                None
        message=True
        return redirect(url_for('logowanie'))

@app.route('/api/logout')
def logout():
    session.pop('name',None)
    session.pop('surname',None)
    session.pop('email',None)
    session.pop('id',None)    
    return redirect(url_for('index'))

@app.route('/setuser')
def setuser():
    return render_template("setuser.html")

@app.route('/api/log')
def name():
    return {'log':session['name']}

@app.route('/api/in')
def LogIt():
    name=session.get('name')
    if name is not None:
        return {'log':True}
    return {'log':False}

@app.route('/index')
def index():
    return render_template("index.html")

@app.route('/logowanie')
def logowanie():
    return render_template("logowanie.html")
@app.route('/rejestracja')
def rejestracja():
    return render_template("rejestracja.html")

@app.route('/myoffers')
def myoffers():
    return render_template("myoffers.html")

@app.route('/addoffer')
def addoffers():
    return render_template("addoffer.html")
@app.route('/api/get_add_offer',methods = ['POST', 'GET'])
def get_add_offer():
    if request.method == 'GET':
        return "ERROR"
    if request.method == 'POST':
        Sell_or_Rent = request.form['Sell_or_Rent']
        Meters=request.form['Meters_from']
        Price=request.form['Price_from']
        Description=request.form['Description']
        Address=request.form['address']
        City=request.form['city']
        Image=request.form['Image'].split("=,")
        Data=time.strftime("%Y-%m-%d", time.localtime())
        cursor = mysql.connection.cursor()
        if len(Image)>=2:
            Image[0]+="="
        cursor.execute('''INSERT INTO ogłoszenia (idklienta,Metry,Cena,Klasa,Zdjecia,Opis,Data, Adres,Miasto ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)''', (session['id'],Meters,Price,Sell_or_Rent,Image[0],Description,Data,Address,City))
        mysql.connection.commit()
        cursor.close()
        is_create_page(Sell_or_Rent,Meters,Price,Description,Address,City,Image,Data,False)
        return redirect(url_for('addoffers'))
  
@app.route('/api/download')
def get_offers():
    offers=[]
    cursor = mysql.connection.cursor()
    cursor.execute('''
        SELECT 
            ogłoszenia.idogłoszenia,
            klient.Email,
            ogłoszenia.Metry,
            ogłoszenia.Cena,
            ogłoszenia.Klasa,
            ogłoszenia.Zdjecia,
            ogłoszenia.Opis,
            ogłoszenia.Data,
            ogłoszenia.Adres,
            ogłoszenia.Miasto
        FROM ogłoszenia
        JOIN klient ON ogłoszenia.idklienta = klient.Idklient
    ''')
    rows = cursor.fetchall()
    cursor.close()
    for row in rows:
      try:
          offers.append({"id":row[0],"email":row[1],"Meters":row[2],"Price":row[3],"class":row[4],"Images":row[5],"Description":row[6],"data":row[7],"Address":row[8],"City":row[9]})
      except Exception:
          None
    return jsonify(offers)
    
@app.route('/api/message')
def get_message():
    return {'message': message}

@app.route('/offer/<int:offer>')
def is_offers(offer):
    return render_template(f'''offer/{offer}.html''', offer=offer)

@app.route('/delete_offer/<int:offer>', methods=['DELETE'])
def delete_offer(offer):
  os.remove(f'C:/xampp/htdocs/pracaobrona/react-with-flask/offer/{offer}.txt')
  os.remove(f'C:/xampp/htdocs/pracaobrona/react-with-flask/offer/{offer}.html')
  cur = mysql.connection.cursor()
  cur.execute(
        '''DELETE FROM ogłoszenia WHERE idogłoszenia = %s''',
        (offer,)
    )
  mysql.connection.commit()
  cur.close()
  return jsonify({"status": "success", "deleted_offer": offer}), 200

@app.route('/api/myoffers')
def get_myoffers():
    offers=[]
    cursor = mysql.connection.cursor()
    cursor.execute(f'''
        SELECT 
            ogłoszenia.idogłoszenia,
            klient.Email,
            ogłoszenia.Metry,
            ogłoszenia.Cena,
            ogłoszenia.Klasa,
            ogłoszenia.Zdjecia,
            ogłoszenia.Opis,
            ogłoszenia.Data,
            ogłoszenia.Adres,
            ogłoszenia.Miasto
        FROM ogłoszenia
        JOIN klient ON ogłoszenia.idklienta = klient.Idklient WHERE idklienta = {session['id']}
    ''')
    rows = cursor.fetchall()
    cursor.close()
    for row in rows:
      try:
          offers.append({"id":row[0],"email":row[1],"Meters":row[2],"Price":row[3],"class":row[4],"Images":row[5],"Description":row[6],"data":row[7],"Address":row[8],"City":row[9]})
      except Exception:
          None
    return jsonify(offers)

@app.route('/api/edit', methods=['POST', 'GET'])
def get_edit_offer():
    if request.method == 'GET':
        return "ERROR"
    if request.method == 'POST':
        session['id_offer'] = request.form['offer']
        return redirect(url_for('editoffer'))
    
@app.route('/editoffer')
def editoffer():
    return render_template("editoffer.html")

@app.route('/api/edit_my_offers')
def edit_myoffers():
    offers=[]
    cursor = mysql.connection.cursor()
    cursor.execute(f'''
        SELECT 
            ogłoszenia.idogłoszenia,
            klient.Email,
            ogłoszenia.Metry,
            ogłoszenia.Cena,
            ogłoszenia.Klasa,
            ogłoszenia.Zdjecia,
            ogłoszenia.Opis,
            ogłoszenia.Data,
            ogłoszenia.Adres,
            ogłoszenia.Miasto
        FROM ogłoszenia
        JOIN klient ON ogłoszenia.idklienta = klient.Idklient WHERE idklienta = {session['id']} and ogłoszenia.idogłoszenia = {session['id_offer']}; 
    ''')
    result = cursor.fetchone()
    for row in range(len(result)):
        offers.append(result[row])
    return jsonify(offers) 
@app.route('/api/update_edit_offer', methods=['POST', 'GET'])
def update_edit_offer():
    if request.method == 'GET':
        return "ERROR"
    if request.method == 'POST':
        Sell_or_Rent=request.form['Sell_or_Rent']
        Meters_from=request.form['Meters_from']
        Price_from=request.form['Price_from']
        address=request.form['address']
        city=request.form['city']
        Description=request.form['Description']
        Image=request.form['Image'].split("=,")
        if len(Image)>=2:
            Image[0]+="="
        Data=time.strftime("%Y-%m-%d", time.localtime())
        cur = mysql.connection.cursor()
        cur.execute('''UPDATE ogłoszenia SET idklienta = %s , Metry  = %s , Cena = %s ,Klasa = %s , Zdjecia  = %s , Opis = %s , Data = %s ,Adres = %s , Miasto  = %s  WHERE idogłoszenia = %s''', (session['id'],Meters_from,Price_from,Sell_or_Rent,Image[0],Description,Data,address,city,session['id_offer']))
        mysql.connection.commit()
        cur.close()
        is_create_page(Sell_or_Rent,Meters_from,Price_from,Description,address,city,Image,Data,True)
        session.pop('id_offer',None)
        return redirect(url_for('myoffers'))
@app.route('/api/images')
def api_images():
    file=open(f'../offer/{str(session['id_offer'])}.txt')
    images= file.read()
    images=images.split("\n")
    for line in range(len(images)):
        if(images[line]==""):
            images.pop(line)
    return {'images':images}
if __name__ == '__main__':
    app.run(host='localhost',debug=True)
