import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': 'http://localhost:5000',
      '/delete_offer': 'http://localhost:5000',
      '/logowanie': {
      target: 'http://localhost:5173',
      changeOrigin: true,
      secure: false,
      rewrite: path => path.replace(/^\/logowanie/, ''),
    },
    '/index': {
      target: 'http://localhost:5173',
      changeOrigin: true,
      secure: false,
      rewrite: path => path.replace(/^\/index/, ''),
    },
      '/rejestracja': {
      target: 'http://localhost:5173',
      changeOrigin: true,
      secure: false,
      rewrite: path => path.replace(/^\/rejestracja/, ''),
    },
    '/myoffers': {
      target: 'http://localhost:5173',
      changeOrigin: true,
      secure: false,
      rewrite: path => path.replace(/^\/myoffers/, ''),
    },
      '/setuser': {
      target: 'http://localhost:5173',
      changeOrigin: true,
      secure: false,
      rewrite: path => path.replace(/^\/setuser/, ''),
    },
    '/addoffer': {
      target: 'http://localhost:5173',
      changeOrigin: true,
      secure: false,
      rewrite: path => path.replace(/^\/addoffer/, ''),
    },
      '/editoffer': {
      target: 'http://localhost:5173',
      changeOrigin: true,
      secure: false,
      rewrite: path => path.replace(/^\/editoffer/, ''),
    },
    },
  },
})
