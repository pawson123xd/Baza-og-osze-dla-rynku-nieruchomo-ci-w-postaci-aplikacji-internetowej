import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import {Logo} from "./components/Title.jsx";
import { useState, useEffect } from 'react'
function FormgetRegister() {
  const [name, setName] = useState("");
  const [surname, setSurname] = useState("");
  const [password, setPassword] = useState("");
  const [errorvalidaj, setErrorvalidaj] = useState(false);
  const [ismessage, setismessage] = useState(false);
    useEffect(() => {
    fetch('/api/message').then(res => res.json()).then(data => {
      setismessage(data.message);
    });
  }, []);
  const validation = async (e) =>{
    if((name[0] === name[0].toUpperCase())&&(name[0] === name[0].toUpperCase())&&(password.length>=10 && password[0] === password[0].toUpperCase())&&(surname[0] === surname[0].toUpperCase())&&(surname[0] === surname[0].toUpperCase())){
      return
    }
    else{
    setErrorvalidaj(true)
    e.preventDefault();
    }
  }
  return (
    <>
    <Logo></Logo>
    <div className="container">
      <div className="row">
        <div className="border border-dark rounded mt-5">
            <form method="post" action="/api/register">
              <p className="text-dark text-center mt-5">Rejestracja</p>
                  <label className="mt-3 col-lg-4 col-10  ms-3">
                  </label>
                  <label className="mt-3 col-lg-4 col-10   ms-3">
                    <input className="form-control" type="email" name="email"
                      placeholder="Email" required/>
                  </label>
                  <label className=" col-lg-4 ms-3">
                  </label>
                  <label className=" col-lg-4 col-10 mt-3 ms-3">
                      <input className="form-control" type="text" name="name" value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Imie" required/>
                  </label>
                  <label className=" col-lg-4 ms-3">
                  </label>
                  <label className=" col-lg-4 col-10  mt-3 ms-3">
                      <input className="form-control" type="text" name="surname" value={surname}
                      onChange={(e) => setSurname(e.target.value)}
                      placeholder="Nazwisko" required/>
                  </label>
                  <label className=" col-lg-4 ms-3">
                  </label>
                  <label className="mt-3 col-lg-4 col-10  ms-3"><input className="form-control" type="password" name="password"  value={password}
                      onChange={(e) => setPassword(e.target.value)} placeholder="Hasło" required ></input>
                      {errorvalidaj && <div>Imie i Nazwisko z dużej litery i hasło minimum 10 znak i początek z dużej litery</div>}
                      {ismessage && <div>email już jest wykorzystany</div>}
                  </label>
                  <label className="mt-3 col-lg-4 ms-3">
                  </label>
                  <div className="mt-5"> 
                  </div>
                  <div className="mt-3 p-3 d-flex justify-content-center">
                    <button className="btn btn-primary col-lg-3 col-10" onClick={validation}>Utwórz konto</button>
                  </div>
              </form>
          </div>
        </div>
    </div>
    </>
  )
}
export default FormgetRegister