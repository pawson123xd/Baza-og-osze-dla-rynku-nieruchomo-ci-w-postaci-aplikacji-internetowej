import { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import {LogingSet} from "./components/Log-in-Set";
import {Getoffers} from "./components/getoffers";
function App() {
  const [sessionvalut, setsessin] = useState(false);
  useEffect(() => {
    fetch('/api/in').then(res => res.json()).then(data => {
      setsessin(data.log);
    });
  }, []);
  return (
    <>
      <LogingSet session={sessionvalut}/>
      <div className="filters">
      <Getoffers offers={'/api/download'}/>
      </div>
    </>
  )
}
export default App