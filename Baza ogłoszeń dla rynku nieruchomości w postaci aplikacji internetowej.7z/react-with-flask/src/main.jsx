import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';


import App from './App.jsx';

import Formgetlog from './getlog.jsx';

import FormgetRegister from './FormgetRegister.jsx';

import My_offert from './Myoffert.jsx';

import FormSetuser from './setuser.jsx';

import Formaddoffer from './addoffer.jsx';
import Formeditoffer from './editoffer.jsx';

const root = document.getElementById('root');
 
if (root) {

  createRoot(root).render(
<BrowserRouter>
<Routes>
<Route path="/" element={<App />} />
<Route path="/index" element={<App />} />
<Route path="/logowanie" element={<Formgetlog />} />
<Route path="/rejestracja" element={<FormgetRegister />} />
<Route path="/myoffers" element={<My_offert />} />
<Route path="/setuser" element={<FormSetuser />} />
<Route path="/addoffer" element={<Formaddoffer />} />
<Route path="/editoffer" element={<Formeditoffer />} /> 
<Route path="*" element={<App />} />
</Routes>
</BrowserRouter>

  );

}
 
 
 
 