import { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import {Logo} from "./components/Title.jsx";
function Formgetlog() {
  const [ismessage, setismessage] = useState(false);
    useEffect(() => {
    fetch('/api/message').then(res => res.json()).then(data => {
      setismessage(data.message);
    });
  }, []);
  return (
    <>
    <Logo />
    <div className="container">
      <div className="row">
        <div className="border border-dark rounded mt-5">
            <form method="post" action="/api/login">
              <p className="text-dark text-center mt-5">Zalogu sie</p>
                  <label className="mt-3 col-lg-4 col-10 col-10 mx-auto d-block text-center">
                    <input className="form-control" type="text" name="email" placeholder="Email"required/>
                  </label>
                  <label className="col-4 m-1">
                  </label>
                  <label className="col-lg-4 col-10 mx-auto d-block text-center">
                    <input className="form-control" type="password" name="password" placeholder="Hasło" required />
                  </label>
                  <label className="mt-3 col-lg-4 ms-3">
                  </label>
                  <label className="mt-3 col-lg-4 ms-3 text-center">
                    {ismessage &&<p>hasło  lub email nie prawidłowe</p>}
                  </label>
                  <div className="mt-3 p-3 d-flex justify-content-center">
                    <button className="btn btn-primary col-lg-3">Zaloguj</button>
                  </div>
              </form>
          </div>
        </div>
    </div>
    </>
  )
}
export default Formgetlog