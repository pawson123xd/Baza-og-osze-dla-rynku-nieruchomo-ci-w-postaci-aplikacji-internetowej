import  { useState, useEffect} from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import {LogingSet} from "./components/Log-in-Set";

function Formeditoffer() {
  const [dataoffer, setdata_offer] = useState();
  const [descriptionoffer, setdescriptionoffer] = useState('');
  const [imageSrc, setImageSrc] = useState('');
  const [imagememory,setimagememorySrc]= useState([]);
  const [choice, setchoice] = useState('');
  const [choicemessage, setchoicemessage] = useState(false);
  const [meters,setMeters]= useState(0);
  const [price,setPrice]= useState(0);
  const [price_or_meters_message, setchoiceprice_or_meters_message] = useState(false);
  const [city,setcity]= useState('');
  const [address,setaddress]= useState('');
  const [city_or_address, setcity_or_address_message] = useState(false);
  const validation = async (e) =>{
    if((city=='') || (address=='')){
      setcity_or_address_message(true)
      e.preventDefault();
    }
    if((price==0) || (meters==0) || (price==null) || (meters==null)){
      setchoiceprice_or_meters_message(true)
      e.preventDefault();
    }
    else if(choice==''){
      setchoicemessage(true)
      e.preventDefault();
    }
    else{
    setchoiceprice_or_meters_message(false)
    setchoicemessage(false)
    setcity_or_address_message(false)
    }
  }

  const handleFileChange = (event) => {
    Array.from(event.target.files).forEach(file =>{
      if (!file) return;
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setImageSrc(e.target.result);
          setimagememorySrc(prev => [...prev, e.target.result]);
        };
        reader.readAsDataURL(file);
      } else {
        alert('Obsługiwane są tylko pliki graficzne (jpg, png, gif itp.).');
      }
    })
  };
  const  handleRemoveImage = (index) =>{
    setimagememorySrc(current => [
      ...current.slice(0, index),
      ...current.slice(index + 1)
    ]);
  }
  useEffect(() => {
    fetch('/api/edit_my_offers').then(res => res.json()).then(data => {
      setdata_offer(data);
    });
  }, []);
  const [sessionvalut, setsessin] = useState();
  useEffect(() => {
    fetch('/api/in').then(res => res.json()).then(data => {
      setsessin(data.log);
    });
  }, []);
  const  handleChange = (Change) =>{
    setchoice(Change)
  }
useEffect(() => {
  if (dataoffer && Array.isArray(dataoffer)) {
    console.log(dataoffer)
    fetch('/api/images').then(res => res.json()).then(data => {
      setImageSrc(data.images);
      setimagememorySrc(data.images);
    });
    setchoice(dataoffer[4])
    setMeters(dataoffer[2])
    setPrice(dataoffer[3])
    setaddress(dataoffer[8])
    setcity(dataoffer[9])
    setdescriptionoffer(dataoffer[6])
  }
}, [dataoffer]);
  return (
    <>
    <LogingSet session={sessionvalut}/>
      <div className="filters">
        <div className="windows border border-dark border-top-0  border-bottom-0">
          <form method='post' action="/api/update_edit_offer">
          <div className="container">
            <div className="row align-items-start">
                <div className="form-check m-2 position-relative">
                  <input className="form-check-input"  type="radio" name='choice'  id="exampleRadios1" onClick={() => handleChange("Sprzedaż")} value={choice} checked={choice === "Sprzedaż"}
          onChange={() => handleChange("Sprzedaż")}/>
                  <label className="form-check-label" htmlFor="exampleRadios1">
                    Sprzedaż
                  </label>
                  <button className=' position-absolute btn btn-primary top-0 end-0 m-3 p-3' onClick={validation}>Dodaj oferte</button>
                </div>
                <div className="form-check m-2">
                  <input  className="form-check-input" type="radio" name='choice'  id="exampleRadios2" onClick={() => handleChange("Wynajem")}  value={choice} checked={choice === "Wynajem"} onChange={() => handleChange("Wynajem")}/>
                  <label className="form-check-label" htmlFor="exampleRadios2">
                    Wynajemę
                  </label>
                  {choicemessage && <p className='pt-3'>Brak wybranej kategorii</p>}
                </div>
                <input type="hidden" name='Sell_or_Rent' value={choice} />
                <div className="list-group-item p-1 m-1 col-lg-2 col-11">
                  <label className="form-check-label" htmlFor="exampleRadios2">
                    Podaj metry
                  </label>
                  <input type="number" defaultChecked={meters} name="Meters_from"  onChange={(e) => setMeters(e.target.value)} className="form-control" min="0" step="0.01" placeholder="Metry" value={meters} required/> 
                </div>
                <div className="list-group-item p-1 m-1 col-lg-2 col-11">
                    <label className="form-group">
                      Podaj cene
                    </label>
                    <input type="number" defaultChecked={price} name="Price_from" onChange={(e) => setPrice(e.target.value)} className="form-control" min="0" step="0.01" placeholder="Ceny"  value={price} required/> 
                </div>
                <div className="list-group-item p-1 m-1 col-lg-2 col-11">
                  <label className="form-group">
                    Podaj adres
                  </label>
                  <input type="text"  defaultChecked={address} name="address"  onChange={(e) => setcity(e.target.value)} className="form-control"  placeholder="Adres"  value={city} required/> 
                </div>
                <div className="list-group-item p-1 m-1 col-lg-2  col-11">
                  <label className="form-check-label" htmlFor="exampleRadios2">
                    Podaj miasto
                  </label>
                  <input type="text"  name="city"  defaultChecked={city}  onChange={(e) =>  setaddress(e.target.value)} className="form-control"  value={address} placeholder="Miasto" required/> 
                </div>
                {city_or_address && <p>Brak ustawionego ceny lub matrów</p>}
                {price_or_meters_message && <p>Brak adres lub miasta</p>}
                <div className="form-group">
                  <label htmlFor="exampleFormControlTextarea1">Opis</label>
                  <textarea defaultValue={descriptionoffer} id="w3review" className='form-control' name="Description" rows="4" cols="50"></textarea>
              </div>
              <div className="form-group ">
                <div className='btn col-lg-4 col-8'></div>
                <input type="file"  id="my-file-input" accept="image/*" onChange={handleFileChange} multiple style={{ display: "none" }} />
                <input type="hidden" name='Image' value={imagememory} style={{ display: "none" }} />
                <label htmlFor="my-file-input" className="my-file-label btn btn-primary col-lg-3  col-3 m-4">
                  Dodaj obrazy
                </label>
                  {imageSrc && (  <div className="mt-5 image">
                      {imagememory.map((src, index) => (
                        <div key={index} className={`position-relative d-inline-block m-2`} >
                          <button
                            type="button"
                            className="btn btn-danger btn-sm position-absolute"
                            style={{ zIndex: 10 }}
                           onClick={() => handleRemoveImage(index)}
                           >
                            Usuń
                          </button>
                          <img
                            src={src}
                            alt={`Załadowane zdjęcie ${index + 1}`}
                            className="img-fluid mt-4"
                            style={{ maxWidth: '250px' }} 
                          />
                        </div>
                      ))}
                    </div>)}
              </div>
            </div>
          </div>
          </form>
        </div>
    </div>
    </>
  )
}
export default Formeditoffer