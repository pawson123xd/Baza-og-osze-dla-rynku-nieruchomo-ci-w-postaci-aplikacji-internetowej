import { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import {LogingSet} from "./components/Log-in-Set";
function FormSetuser() {
  const [name, setName] = useState("");
  const [repeat_password, setrepeat_password] = useState("");
  const [surname, setSurname] = useState("");
  const [password, setPassword] = useState("");
  const [errorvalidaj, setErrorvalidaj] = useState(false);
  const validation = async (e) =>{
    console.log(name)
    if((name[0] === name[0].toUpperCase())&&(name[0] === name[0].toUpperCase())&&(password.length>=10 &&
      password[0] === password[0].toUpperCase())&&(surname[0] === surname[0].toUpperCase())&&
      (surname[0] === surname[0].toUpperCase())&&(name[0] === name[0].toUpperCase())&&(password===repeat_password)){
      return
    }
    else{
    setErrorvalidaj(true)
    e.preventDefault();
    }
  }
  const [sessionvalut, setsessin] = useState();
    useEffect(() => {
      fetch('/api/in').then(res => res.json()).then(data => {
        setsessin(data.log);
      });
    }, []);
  const [ismessage, setismessage] = useState(false);
    useEffect(() => {
    fetch('/api/message').then(res => res.json()).then(data => {
      setismessage(data.message);
    });
  }, []);
  const [dataperson, setidataperson] = useState([]);
  useEffect(() => {
    fetch('/api/setuser')
      .then(res => res.json())
      .then(data => {
        setidataperson(data);
        setName(data[0]?.name || "");
        setSurname(data[0]?.surname || "");
      });
  }, []);
  return (
    <>
    <LogingSet session={sessionvalut}/>
    {sessionvalut && (<div className="container">
      <div className="row">
        <div className="border border-dark rounded mt-5">
            <form method="post" action="/api/get_update_user">
              <p className="text-dark text-center mt-5">Dane</p>
              <p className="text-dark  mt-1 ms-3 ">Email:{dataperson[0]?.email}</p>
                  <label className="mt-3  col-lg-5 ms-3  col-10 mx-auto d-block text-center">
                    <input defaultValue={dataperson[0]?.name} onChange={(e) => setName(e.target.value)} className="form-control" type="text" name="name" required/>
                  </label>
                  <label className="mt-3  col-lg-5 ms-3  col-10 mx-auto d-block text-center">
                    <input defaultValue={dataperson[0]?.surname} onChange={(e) => setSurname(e.target.value)} className="form-control" type="text" name="surname" required/>
                  </label>
                  <label className="mt-3 col-lg-5 ms-3 col-10 mx-auto d-block text-center"><input onChange={(e) => setPassword(e.target.value)} className="form-control" type="password" name="password" placeholder="Nowe hasło" required></input>
                  </label>
                  <label className="mt-3 col-lg-5 ms-3 col-10 mx-auto d-block text-center"><input onChange={(e) => setrepeat_password(e.target.value)}  className="form-control" type="password" name="repeat_password" placeholder="Powtórz hasło" required></input>
                  </label>
                  <label className="mt-3 col-lg-4 ms-3 text-center">
                    {ismessage &&<p>hasło nie prawidłowe</p>}
                    {errorvalidaj && <p>Imie i Nazwisko z dużej litery i hasło minimum 10 znak i początek z dużej litery lub hasło nie prawidłow</p>}
                  </label>
                  <div className="mt-3 p-3 d-flex justify-content-center">
                    <button className="btn btn-primary col-lg-3 " onClick={validation}>Zapisz</button>
                  </div>
              </form>
          </div>
        </div>
    </div>)}
    </>
  )
}
export default FormSetuser