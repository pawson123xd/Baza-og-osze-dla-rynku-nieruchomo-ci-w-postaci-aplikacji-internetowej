import  { useState, useEffect} from 'react'
export const LogInForm = (props) => {
  const [location, setLocation] = useState('');
  const [choice, setchoice] = useState('');
  const [meters_min,setMeters_min]= useState(0);
  const [price_min,setPrice_min]= useState(0);
  const [meters_max,setMeters_max]= useState(0);
  const [price_max,setPrice_max]= useState(0);
  
  const handlesortChange = (Change) => {
    if (Change === 'Najnowsze') {
      const offersSort = [...props.offers].sort((a, b) => {
        return new Date(b.data).getTime() - new Date(a.data).getTime();
      });
      props.setoffers(offersSort);
    }
    else if (Change === 'Najstarsze') {
      const offersSort = [...props.offers].sort((a, b) => {
        return new Date(a.data).getTime() - new Date(b.data).getTime();
      });
      props.setoffers(offersSort);
    }
    else if (Change==='Najniższej'){
      const offerssort=[...props.offers].sort((a,b)=>a.Price  - b.Price)
      props.setoffers(offerssort)
    }
    else if (Change==='Najwyższej'){
      const offerssort=[...props.offers].sort((a,b)=>b.Price  - a.Price)
      props.setoffers(offerssort)
    }
    else if (Change==='Najwyższej'){
      const offerssort=[...props.offers].sort((a,b)=>a.Meters  - b.Meters)
      props.setoffers(offerssort)
    }
    else{
      const offerssort=[...props.offers].sort((a,b)=>b.Meters  - a.Meters)
      props.setoffers(offerssort)
    }
  };
  const  handleChange = (Change) =>{
    setchoice(Change)
  }
  const handlefilterclear = () => {
    fetch(`${props.operation}`)
      .then(res => res.json())
      .then(data => {
        props.setoffers(data);
        });
    setLocation('')
    setchoice('')
    setMeters_min(0)
    setPrice_min(0)
    setMeters_max(0)
    setPrice_max(0)
  }
    const handlesort = () => {
      const text = location.charAt(0).toUpperCase()+location.slice(1).toLowerCase();
      fetch(`${props.operation}`)
        .then(res => res.json())
        .then(data => {  
          const offer=[...data]
          const offersort=[]
          for (let i = 0; i < offer.length; i++) {
            if((offer[i].Price<price_max && offer[i].Price>price_min || price_min==0 && price_max==0) && (meters_min<offer[i].Meters && offer[i].Meters<meters_max || meters_min==0 && meters_max==0) && (offer[i].class==choice || choice=='') && (offer[i].City==text || location=='') ){
              offersort.push(offer[i])
            }
          }
          props.setoffers(offersort);
        });
    }
  return(
  <>
    <div className="filters">
        <div className="windows">
          <div className="container">
            <div className="row align-items-start">
              <input type="text" onChange={(e) => setLocation(e.target.value)} className="list-group-item border border-dark rounded p-3 m-2 col-lg-6  col-10" placeholder="lokalizacja Miasta"></input> 
              <select onClick={(e) => handleChange(e.target.value)} className="list-group-item border border-dark rounded p-3 m-2 col-lg-2 col-10">
                <option >Domyślnie</option>
                <option value="Sprzedaż">Sprzedaż</option>
                <option value="Wynajem">Wynajem</option>
              </select>
            <select onClick={(e) => handlesortChange(e.target.value)} className="list-group-item border border-dark rounded p-3 m-2 col-lg-2 col-10">
              <option value="Najnowsze">Najnowsze</option>
              <option value="Najstarsze">Najstarsze</option>
              <option value="Najniższej">Najniższej</option>
              <option value="Najwyższej">Najwyższej</option>
              <option value="Powierzechnia: Najniższej">Powierzechnia: Najniższej</option>
              <option value="Powierzechnia: Najwyższej">Powierzechnia: Najwyższej</option>
            </select>
            </div>
          </div>
        </div>
        <div className="windows">
          <div className="container">
            <div className="row">
              <div className="col-lg-1"></div>
              <div className="list-group-item p-1 m-1 col-lg-2 col-12">
                <input type="number" onChange={(e) => setPrice_min(Number(e.target.value))}  className="form-control" min="0" placeholder="Cena min" /> 
              </div>
              <div className="list-group-item p-1 m-1 col-lg-2 col-12">
                <input type="number" onChange={(e) => setPrice_max(Number(e.target.value))}   className="form-control" min="0" placeholder="Cena max" /> 
              </div>
              <div className="list-group-item p-1 m-1 col-lg-2 col-12">
                <input type="number" onChange={(e) => setMeters_min(Number(e.target.value))}   className="form-control" min="0" placeholder="Metry min" /> 
              </div>
              <div className="list-group-item p-1 m-1 col-lg-2 col-12">
                <input type="number" onChange={(e) => setMeters_max(Number(e.target.value))}   className="form-control" min="0" placeholder="Metry max" /> 
              </div>
            </div>
            <div className="row">
              <div className="col-lg-5 col-12 m-3">
              </div>
              <button  type="submit" className="border border-dark rounded btn btn-primary p-3 m-4 col-lg-2 col-10" onClick={handlefilterclear}>
                Wyczyścić
              </button>
              <button  type="submit" className="border border-dark rounded btn btn-primary p-3 m-4 col-lg-2 col-10" onClick={handlesort}>
                Szukaj
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"  className="bi bi-search" viewBox="-2 0 16 19">
                  <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
    </div>
  </>
  )
};