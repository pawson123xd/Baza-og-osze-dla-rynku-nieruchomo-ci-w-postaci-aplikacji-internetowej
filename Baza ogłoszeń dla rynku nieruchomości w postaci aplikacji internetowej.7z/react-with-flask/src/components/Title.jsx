import { Link } from 'react-router-dom';
export const Logo = (props) => (
  <>
      <div className="title">
        <div className="list-group me-5 link">
        <Link to='/index' className='list-group-item list-group-item-action active'>Logo</Link>
        </div>
      </div>
  </>
);