import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link,Navigate } from 'react-router-dom';
import { LogInForm } from './LogInForm';

export const Getoffers = (props) => {
  const [offers, setmemoryoffers] = useState([]);
  const [myoffer, setmyoffers] = useState(false);
  const [is_delete, setis_delete] = useState();

  useEffect(() => {
    setmyoffers(props.offers === '/api/myoffers');
  }, [props.offers]);

  useEffect(() => {
    if (props.offers) {
      fetch(`${props.offers}`)
        .then((res) => res.json())
        .then((data) => {
          setmemoryoffers(data);
          setis_delete(Array(data.length).fill(false))
        });
    }
  }, [props.offers]);
  const handleRemoveOffer = (index, idoffer) => {
    setmemoryoffers((current) => [
      ...current.slice(0, index),
      ...current.slice(index + 1),
    ]);
    axios
      .delete(`/delete_offer/${idoffer}`)
      .then((response) => {
        console.log(response.data.status);
      })
      .catch((error) => {
        console.error('Błąd:', error);
      });
  };

  const setis_delete_validon = (index) => {
    const copy_is_delete = [...is_delete];
    copy_is_delete[index] = !copy_is_delete[index];
    setis_delete(copy_is_delete);
  };

  return (
    <>
      <LogInForm offers={offers} operation={props.offers} setoffers={setmemoryoffers} />

      {myoffer ? (
        <>
          <div className="form-group">
            <div className="btn col-lg-4  col-6"></div>
            <Link to="/addoffer" className="btn btn-primary col-lg-3 col-6 m-4">
              Dodaj ofertę
            </Link>
          </div>

          {offers.map((offer, index) => (
            <div className="windows mt-5" key={offer.id ?? index}>
              <div className="container">
                <div className="rounded bg-body-secondary row fs-5">
                  <div className="position-relative d-inline-block">
                    <div className="btn-sm position-absolute">
                      <a href={`/offer/${offer.id}`}
                        className="btn btn-primary link-offset-2 text-dark link-underline link-underline-opacity-0 btn-sm"
                        style={{ zIndex: 10 }}
                      >
                        Widok
                      </a>
                      <form method="post" action="/api/edit" style={{ display: 'inline-block' }}>
                        <input type="hidden" name="offer" value={offer.id} />
                        <button
                          type="submit"
                          className="btn btn-warning btn-sm"
                          style={{ zIndex: 10, marginLeft: '25px' }}
                        >
                          Edytuj ofertę
                        </button>
                      </form>
                      <button
                        type="button"
                        className="btn btn-danger text-dark btn-sm"
                        style={{ zIndex: 10, marginLeft: '20px' }}
                        onClick={() => setis_delete_validon(index)}
                      >
                        Usuń
                      </button>
                    </div>

                    {is_delete[index] && (
                      <div className="position-relative">
                        <div className="position-absolute bg bg-light col-lg-4 col-6 top-0 end-0 p-3 mt-4">
                          <div className="text-dark fs-6">
                            Czy na pewno chcesz usunąć ogłoszenie?
                          </div>
                          <button
                            type="button"
                            className="btn btn-success p-3 mt-2 text-dark"
                            style={{ marginLeft: '40px' }}
                            onClick={() => setis_delete_validon(index)}
                          >
                            Anuluj
                          </button>
                          <button
                            type="button"
                            className="btn btn-danger p-3 mt-2 text-dark"
                            style={{ marginLeft: '40px' }}
                            onClick={() => handleRemoveOffer(index, offer.id)}
                          >
                            Usuń
                          </button>
                        </div>
                      </div>
                    )}

                    <img
                      src={offer.Images}
                      alt="offer"
                      className="img-fluid mt-4"
                      style={{ maxWidth: '250px' }}
                    />
                  </div>

                  <div className="col-lg-2 col-4 mt-2">
                    <div className="fw-bolder">{offer.Price} zł</div>
                    <div className="mt-3">Adres: {offer.Address}</div>
                    <div className="mt-3">Miasto: {offer.City}</div>
                  </div>

                  <div className="col-lg-2  col-4 mt-2 fw-bolder">{offer.Meters} m&sup2;</div>
                  <div className="col-lg-2 col-4 mt-2 fw-bolder">Stan: {offer.class}</div>
                </div>
              </div>
            </div>
          ))}
        </>
      ) : (
        offers.map((offer, index) => (
          <div className="windows mt-5" key={offer.id ?? index} style={{ marginTop: '60px' }}>
            <div className="container">
              <a
                href={`/offer/${offer.id}`}
                className="rounded bg-body-secondary link-offset-2 text-dark link-underline link-underline-opacity-0 row fs-5"
              >
                <img className="col-lg-4 col-6 p-2 fw-bold" src={offer.Images} alt="offer" />
                <div className="col-lg-2 col-6 mt-2">
                  <div className="fw-bolder">{offer.Price} zł</div>
                  <div className="mt-3">Adres: {offer.Address}</div>
                  <div className="mt-3">Miasto: {offer.City}</div>
                </div>
                <div className="col-lg-2 col-4 mt-2 fw-bolder">{offer.Meters} m&sup2;</div>
                <div className="col-lg-2 col-4 mt-2 fw-bolder">Stan: {offer.class}</div>
              </a>
            </div>
          </div>
        ))
      )}
    </>
  );
};
