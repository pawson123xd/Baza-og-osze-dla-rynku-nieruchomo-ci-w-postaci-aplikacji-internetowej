import { useState, useEffect } from 'react'
import { Link,useNavigate } from 'react-router-dom';
export const LogingSet = (props) =>{
const [logvalut, setlog] = useState(0);
const navigate = useNavigate();
useEffect(() => {
  if(props.session){
      fetch('/api/log').then(res => res.json()).then(data => {
          setlog(data.log);
        });
    }
  }, [props.session]);
return (
  <>
    {props.session ? (
      <div className="title">
      <div className="list-group me-5 link ">
        <Link to='/index' className='list-group-item list-group-item-action active'>Logo</Link>
      </div>
    <select
      name="jezyk"
      className="list-group-item border border-dark rounded ms-auto col-lg-1 col-3  me-5 link"
      onChange={(e) => {
        const Value = e.target.value;
        if (Value) {
          navigate(Value);
        }
      }}
    >
      <option value="">{logvalut}</option>
      <option value="/myoffers">Moje oferty</option>
      <option value="/setuser">Ustawienia</option>
    </select>
      <div className="list-group me-5 link">
        <div className="list-group me-5">
        <a href='/api/logout' className='list-group-item list-group-item-action active'>Wyloguj sie</a>
        </div>
      </div>
      </div>
    ) : (
      <div className="title">
      <div className="list-group me-5 link">
        <Link to='/index' className='list-group-item list-group-item-action active'>Logo</Link>
      </div>
      <div className="list-group  ms-auto me-3 link">
          <Link to='/logowanie' className='list-group-item list-group-item-action active'>Zaloguj się</Link>

      </div>
      <div className="list-group me-5 link">
        <Link to='/rejestracja' className='list-group-item list-group-item-action active'>Utworz konto</Link>
      </div>
      </div>
    )}
  </>
);
};