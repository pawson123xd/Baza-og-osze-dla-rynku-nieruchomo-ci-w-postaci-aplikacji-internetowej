import { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import {LogingSet} from "./components/Log-in-Set";
import {Getoffers} from "./components/getoffers";
function My_offert() {
  const [sessionvalut, setsessin] = useState(0);
  useEffect(() => {
    fetch('/api/in').then(res => res.json()).then(data => {
      setsessin(data.log);
    });
  }, []);
  return (
    <>
    <LogingSet session={sessionvalut}/>
    {sessionvalut && (
    <div>
    <div className="container">
      <div className="row">
          <Getoffers offers={'/api/myoffers'}/>
      </div>
    </div>
    </div>
    )}
    </>
  )
}
export default My_offert